<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'alochat');
define('DB_PASSWORD', 'mmongKp123m');
define('DB_NAME', 'alochat');
define('DB_PORT', '3306');
define('DB_PREFIX', 'cn_');
?>
